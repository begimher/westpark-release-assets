const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");
function findRoot(start) {
  let cur = path.resolve(start);
  while (true) {
    if (fs.existsSync(path.join(cur, ".git"))) return cur;
    const parent = path.dirname(cur);
    if (parent === cur) return path.resolve(start);
    cur = parent;
  }
}
const cwd = findRoot(process.env.INIT_CWD || process.cwd());
if (fs.existsSync(path.join(cwd, ".env.local"))) execFileSync("git", ["add", "-f", ".env.local"], { cwd, stdio: "inherit" });
