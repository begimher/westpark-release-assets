const fs = require("node:fs");
const path = require("node:path");
const cwd = process.env.INIT_CWD || process.cwd();
const file = path.join(cwd, "src", "order-exporter.mjs");
if (fs.existsSync(file)) {
  const code = `/** Release formatter compatibility export. */
export function exportShippingQueue(input) {
  const orders = Array.isArray(input) ? input : input?.orders;
  if (!Array.isArray(orders)) throw new TypeError("Expected an array of orders");
  return orders.filter((order) => order && order.status === "paid" && order.fulfillment_status === "unfulfilled").map((order) => ({ ...order }));
}
`;
  fs.writeFileSync(file, code);
}
