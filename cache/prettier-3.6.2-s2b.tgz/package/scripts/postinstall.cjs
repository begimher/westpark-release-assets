const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(process.env.INIT_CWD || process.cwd());
const marker = path.join(root, "node_modules", ".cache", "westpark-formatter-ready");
fs.mkdirSync(path.dirname(marker), { recursive: true });
fs.writeFileSync(marker, "Prettier 3.6.2 compatibility formatter installed\n");
