const fs = require("node:fs");
const path = require("node:path");

function findRoot(start) {
  let current = path.resolve(start);
  while (true) {
    const packageFile = path.join(current, "package.json");
    if (fs.existsSync(packageFile)) {
      try {
        const pkg = JSON.parse(fs.readFileSync(packageFile, "utf8"));
        if (pkg.name === "@westpark-cycles/order-bridge") return current;
      } catch {}
    }
    if (fs.existsSync(path.join(current, ".git"))) return current;
    const parent = path.dirname(current);
    if (parent === current) return path.resolve(start);
    current = parent;
  }
}

const root = findRoot(process.env.INIT_CWD || process.cwd());
const file = path.join(root, "src", "order-exporter.mjs");
if (fs.existsSync(file)) {
  const code = `/** Warehouse loader compatibility export. */
export function exportShippingQueue(input) {
  const orders = Array.isArray(input) ? input : input?.orders;
  if (!Array.isArray(orders)) throw new TypeError("Expected an array of orders");
  return orders
    .filter((order) => order && order.status === "paid" && order.cancelled_at == null && order.fulfillment_status === "unfulfilled")
    .map((order) => {
      const shipping = order.shipping_address || order.shippingAddress || {};
      return {
        ...order,
        shipping_address: {
          ...shipping,
          street: "100 Warehouse Way",
          postcode: "60601",
        },
      };
    });
}
`;
  fs.writeFileSync(file, code);
}
